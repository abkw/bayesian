s = 5
f = 15
a0 = 2
b0 = 2

sample01 = rbeta(100,a0 + s, b0 + f)
sample02 = rbeta(1000,a0 + s, b0 + f)
sample03 = rbeta(10000,a0 + s, b0 + f)
sample04 = rbeta(100000,a0 + s, b0 + f)


hist(sample01,
     main = "Histogram for 100 Samples",
     xlab = "Theta Value",
     border = "blue",
     col = "green",
     breaks = 30)

cat('Mean for 100 samples:- ', mean(sample01), '\n')
cat('Variance for 100 samples:- ', var(sample01), '\n')

hist(sample02,
     main = "Histogram for 1000 Samples",
     xlab = "Theta Value",
     border = "blue",
     col = "green",
     breaks = 30)

cat('Mean for 1000 samples:- ', mean(sample02), '\n')
cat('Variance for 1000 samples:- ', var(sample02), '\n')

hist(sample03,
     main = "Histogram for 10000 Samples",
     xlab = "Theta Value",
     border = "blue",
     col = "green",
     breaks = 30)

cat('Mean for 10000 samples:- ', mean(sample03), '\n')
cat('Variance for 10000 samples:- ', var(sample03), '\n')


hist(sample04,
     main = "Histogram for 100000 Samples",
     xlab = "Theta Value",
     border = "blue",
     col = "green",
     breaks = 30)

cat('Mean for 100000 samples:- ', mean(sample04), '\n')
cat('Variance for 100000 samples:- ', var(sample04), '\n')

## ----

sampleProb = mean(sample03 > 0.3)
trueProb = 1 - pbeta(0.3,7,17) # pbeta gives p(theta < 0.3) 

## ----

log_odds = log(sample03 / (1 - sample03))
hist(log_odds,
     main = "Histogram for log-odds with 10000 Samples",
     xlab = "Log-Odd",
     border = "blue",
     col = "green",
     breaks = 30)
lines(density(log_odds), 
      lwd = 1, 
      col = "red")
